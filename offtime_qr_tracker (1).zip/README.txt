# Offtime Token QR Tracker MVP

Diese kleine HTML-Datei dient zur Erfassung von Offline-Zeit über QR-Code-gesteuerte Links.

## Verwendung

1. `qr.html` auf einen Webserver oder GitHub Pages/Netlify hochladen
2. QR-Code mit URL `...?start=true` scannen → Startzeit wird gespeichert
3. QR-Code mit URL `...?end=true` scannen → Endzeit wird berechnet

Bei erfolgreicher Dauer (≥ 60 Minuten) wird ein OTT signalisiert.

## Datenschutz

- Keine zentralen Daten, alles läuft lokal im Browser.
- Die Startzeit wird im LocalStorage gespeichert.

Ideal für Events, Retreats oder digitale Detox-Piloten.
